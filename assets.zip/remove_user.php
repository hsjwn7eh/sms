<?php
// مسیر فایل آنلاین بودن کاربران
$online_file = 'online_users.txt';

// دریافت آی‌پی کاربر از درخواست POST
$data = json_decode(file_get_contents('php://input'), true);
$user_ip = $data['ip'] ?? '';

// حذف آی‌پی کاربر از فایل آنلاین‌ها
if (!empty($user_ip)) {
    $online_users = file($online_file, FILE_IGNORE_NEW_LINES);
    $online_users = array_filter($online_users, function($ip) use ($user_ip) {
        return $ip !== $user_ip;
    });
    file_put_contents($online_file, implode(PHP_EOL, $online_users) . PHP_EOL);
}
?>
